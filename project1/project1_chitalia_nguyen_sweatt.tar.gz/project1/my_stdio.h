#include <cstdio>

void Perror(const char *input, int old_errno);