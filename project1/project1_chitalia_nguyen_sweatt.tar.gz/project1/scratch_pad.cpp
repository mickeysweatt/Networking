// to make a HEAD request from a GET Request
std::string headRequestStr 
                     = "HEAD "  + req.GetRequestURL()
                     + " HTTP/" + req.GetVersion() +
                     "\r\n\r\n";

HttpRequest headRequest;
headRequest.ParseRequest(headRequestStr.c_str(),
                         headRequestStr.length());
headRequest.SetPort(req.GetPort());
char buf[1024];
headRequest.FormatRequest(buf);
printf("\nRequest:\n--------- \n%s\n",buf);

HttpResponse headResponse;
requestFromServer(headRequest, 
                  &client, 
                  &headResponse);